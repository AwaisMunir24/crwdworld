import './App.css';
import Mainlayout from './layout/Mianlayout';
function App() {
  return (
    <>
     <Mainlayout/>
    </>
  );
}

export default App;
