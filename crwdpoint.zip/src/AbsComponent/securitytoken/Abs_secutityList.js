import React, { Component } from 'react';
import './Abs_secutityList.css';
const Abs_secutityList=(props)=>{
const{para}=props;
return(

    <>
        
           <div className='box'>
            <p>{para}</p>
            </div> 
    
    </>

)



}
export default Abs_secutityList;