import React, { Component } from 'react';
import './Abs_Prospective.css';
import Prospective from '../../components/prospective/Prospestive';
const Abs_Prospective=(props)=>{
const {Prospara}=props;
return(

<>
<div className='rounder-broder'>
<p>{Prospara}</p>
</div>

</>



)



}
export default Abs_Prospective;