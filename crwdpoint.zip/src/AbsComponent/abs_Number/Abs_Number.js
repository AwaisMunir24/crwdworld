import React, { Component } from 'react';
import './Abs_Number.css';
const Abs_Number=(props)=>{
const{title}=props;
return(

<>
<div className='vogon-number'>
    <div className='outer'>
        <h2>{title}</h2>
    </div>
</div>
</>

)



}
export default Abs_Number;